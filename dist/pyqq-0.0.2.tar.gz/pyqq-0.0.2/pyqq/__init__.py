#!/usr/bin/env python
# encoding: utf-8
"""
__init__.py

Created by kula on 2010-11-12.
Copyright (c) 2010 __MyCompanyName__. All rights reserved.
"""

from api import QQ