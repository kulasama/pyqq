from setuptools import setup     


    
setup(
        name = 'pyqq',
        version = '0.0.2',
        description = "nsfocus qq client library",
        license = "gpl3",
        author = "kula",
        author_email = "kulasama@gmail.com",
        url = "http://www.nsfocus.com",
        tests_require = ['nose'],
        packages = ['pyqq',],
)
